import java.sql.*;
import java.util.Scanner;

public class App {
    //Function used for searching purchase orders using the client ID that is input.
    public static void POclient(){
        try{
            System.out.println("Type client ID for purchase order searching:");
        Scanner input = new Scanner(System.in);
        //User then inputs the desired client ID.
        String clientID = input.nextLine();

        //SQL connection ------------------------------------------
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql: //127.0.0.1:3306/mydb", "root", "root");
        Statement stmt = con.createStatement();
        //Takes the submitted client ID and then searches the purchase order table.
        String sqlSt = "SELECT * FROM pos895 WHERE clientComp895 =" + clientID + ";";
        ResultSet rs = stmt.executeQuery(sqlSt);
        
        //Prints through a while loop
        while(rs.next()){
            int poNo = rs.getInt("poNo895");
            String clientComp = rs.getString("clientComp895");
            String dateOfPO = rs.getString("dateOfPO895");
            String status = rs.getString("status895");
        
            System.out.println(poNo + " | " + clientComp + " | " + dateOfPO + "|" + status);
        }
            //Closes connections
            con.close();
            input.close();
        }
        catch (Exception e){
            System.out.println(e);
        }
        
    }
    //Function for submitting purchase orders
    public static void POsubmit(){
        try{
            Scanner input = new Scanner(System.in);
                
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql: //127.0.0.1:3306/mydb", "root", "root");
            Statement stmt = con.createStatement();
            System.out.println("Type sql statement for submitting to PO table table:");
            String sqlSt = input.nextLine();

            stmt.executeUpdate(sqlSt);
            System.out.println("Submission of data completed");
            con.close();
            input.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    //Return line information for specific purchase order
    public static void lineInfo(){
        try{
            System.out.println("Type PO number for purchase order searching:");
        Scanner input = new Scanner(System.in);
        String poNo = input.nextLine();

        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql: //127.0.0.1:3306/mydb", "root", "root");
        Statement stmt = con.createStatement();
        String sqlSt = "SELECT * FROM line895 WHERE poNo895 =" + poNo + ";";
        ResultSet rs = stmt.executeQuery(sqlSt);

        while(rs.next()){
            int poNo1 = rs.getInt("poNo895");
            String lineNo = rs.getString("lineNo895");
            String partNo = rs.getString("priceOrdered895");
            Float priceOrdered = rs.getFloat("priceOrdered895");
            int qty = rs.getInt("qty895");
        
            System.out.println(poNo1 + " | " + lineNo + " | " + partNo + "|" +  priceOrdered + "|" +qty);
        }

            con.close();
            input.close();
        }
        catch (Exception e){
            System.out.println(e);
        }
    }


    



    

    public static void main(String[] args) 
    {
        
        try
        {
            Scanner input = new Scanner(System.in);
            System.out.println("For parts information, type 'Parts'. For purchase order submission, type 'PO submission'. For lines of purchase order, type 'Lines': ");
            String sqlChoice = input.nextLine();

            if(sqlChoice.equals("Parts") || sqlChoice.equals("parts")){
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql: //127.0.0.1:3306/mydb", "root", "root");
                Statement stmt = con.createStatement();
                System.out.println("Type sql statement:");
                String sqlSt = input.nextLine();
                ResultSet rs = stmt.executeQuery(sqlSt);

            while(rs.next()){
                int partNo = rs.getInt("partNo895");
                String partName = rs.getString("partName895");
                float currentPrice = rs.getFloat("currentPrice895");

                System.out.println(partNo + " | " + partName + " | " + currentPrice);
            }

            
    
            con.close();
            input.close();
            }

            if(sqlChoice.equals("Lines") || sqlChoice.equals("lines")){
                    
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql: //127.0.0.1:3306/mydb", "root", "root");
                Statement stmt = con.createStatement();
                System.out.println("Type sql statement for submitting to Line table:");
                String sqlSt = input.nextLine();

                stmt.executeUpdate(sqlSt);
                System.out.println("Submission of data completed");    
                
                con.close();
                input.close();
            }
           
            if(sqlChoice.equals("PO submission")){
                System.out.println("Submit a PO by typing 'Submit', Find purchase orders by client ID by typing 'Client', To find lines information about a specific PO by typing 'lineInfo':");
                String SubOrClient = input.nextLine();

                if(SubOrClient.equals("Submit") || SubOrClient.equals("submit")){
                    POsubmit();
                }

                if(SubOrClient.equals("Client") || SubOrClient.equals("client")){
                    POclient();
                }

                if(SubOrClient.equals("lineInfo")){
                   lineInfo();
                }

                
                
            }
            
            
        }
        
        catch(Exception e){
            System.out.println(e);
        }
    }
}

